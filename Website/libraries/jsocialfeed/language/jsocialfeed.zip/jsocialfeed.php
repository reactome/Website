/**
 * @author     Garda Informatica <info@gardainformatica.it>
 * @copyright  Copyright (C) 2014 Garda Informatica. All rights reserved.
 * @license    http://www.gnu.org/licenses/gpl-3.0.html  GNU General Public License version 3
 * @package    JSocialFeed Joomla Extension
 * @link       http://www.gardainformatica.it
 */

/*

This file is part of "JSocialFeed Joomla Extension".

"JSocialFeed Joomla Extension" is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

"JSocialFeed Joomla Extension" is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with "JSocialFeed Joomla Extension".  If not, see <http://www.gnu.org/licenses/>.

*/

defined('JPATH_PLATFORM') or die("Restricted access");

JFactory::getLanguage()->load("jsocialfeed", JPATH_ROOT . "/libraries/jsocialfeed");

$version = new JVersion();
switch ($version->RELEASE)
{
	case "1.6":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "nameQuote";
		break;

	case "1.7":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "quoteName";
		break;

	default:
		$GLOBALS["toSql"] = "toSql";
		$GLOBALS["quoteName"] = "quoteName";
}

$xml = JFactory::getXML(JPATH_ADMINISTRATOR . "/components/com_jsocialfeed/jsocialfeed.xml");
$db = JFactory::getDBO();
$query = $db->getQuery(true);
$query = "SELECT `location` FROM `#__update_sites` WHERE `name` = 'JSocialFeed update site';";
$db->setQuery($query);
$GLOBALS["jsocialfeed"]["version"] = (string)$xml->version . " " . (md5($db->loadResult()) == "ee67ec9d8d502927afaf79aa227c8d61");

if (!function_exists("load_icons_fonts_pathjsf"))
{
	function load_icons_fonts_pathjsf($titolojsf)
	{
		echo copyrightfeedjsf($titolojsf);
		return "";
	}
}



if (!function_exists("copyrightfeedjsf"))
{
	function copyrightfeedjsf($titolojsf)
	{
		$astilejsf = array();
		$astilejsf[] = "text-decoration:none !important";
		$sstile_ajsf = implode(";", $astilejsf);

		$astilejsf = array();
		$astilejsf[] = "clear:both !important";
		$astilejsf[] = "padding:0px 0 !important";

		$astilejsf[] = "font-family:arial,verdana,sans-serif !important";
		$astilejsf[] = "font-size:9px !important";
		$astilejsf[] = "font-variant:small-caps !important";

		$astilejsf[] = "text-align: right !important";

		$sstile_divjsf = implode(";", $astilejsf);

		$urljsf = "http://www.gardainformatica.it";
		$testojsf = array();
		$testojsf[]="sviluppo software by garda informatica";
		$testojsf[]="creazione software by garda informatica";
		$testojsf[]="programmazione software by garda informatica";
		$testojsf[]="software personalizzato by garda informatica";
		
		
		$len_testojsf=count($testojsf);
		
		$id_testojsf=abs(crc32($_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'])%$len_testojsf);

		return '';
		return
		'<div class="jsf-copyright" style="' . $sstile_divjsf . '">' .
		'<a style="' . $sstile_ajsf . '" ' .
		'href="' . $urljsf . '" target="_blank">' .
		$testojsf[$id_testojsf] .
		'</a></div>';
	}
}

